//Seyed Tavafi
//CS3310
//Midterm
//linear search algorithm ( for unsorted array)
//Optimal algorithm for unsorted array is linear search algorithm
import java.util.Arrays;
import java.util.Random;

class Main {

    public static void main(String[] args) {
        /* ********* FIRST TEST ********* */
        System.out.println("input size : 100");

        int firstSum = 90;

        int firstArrayNum = 100;

        int[] firstArray = new int[firstArrayNum];

        Random rand = new Random();

        for (int i = 0; i < firstArrayNum; i++) {
            firstArray[i] = rand.nextInt(100) - 50;
        }
        System.out.println("sum is :" +firstSum);
//        System.out.println(Arrays.toString(firstArray));

        long firstStartTime = System.nanoTime();
        find(firstArray, firstSum);
        long firstEndTime = System.nanoTime();
        long firstTotalTime = firstEndTime - firstStartTime;
        System.out.println("Complexity of Time : " + (double) firstTotalTime / 1000000000 + " Seconds");
        System.out.println();

        /* ********* SECOND TEST ********* */
        System.out.println("input size : 1000");

        int secondSum = 90;

        int secondArrayNum = 1000;

        int[] secondArray = new int[secondArrayNum];

        for (int i = 0; i < secondArrayNum; i++) {
            secondArray[i] = rand.nextInt(1000) - 500;
        }

        long secondStartTime = System.nanoTime();
        find(secondArray, secondSum);
        long secondEndTime = System.nanoTime();
        long secondTotalTime = secondEndTime - secondStartTime;
        System.out.println("Complexity of Time : " + (double) secondTotalTime / 1000000000 + " Seconds");
        System.out.println();

        /* ********* THIRD TEST ********* */
        System.out.println("input size : 100000");

        int thirdSum = 90;

        int thirdArrayNum = 100000;

        int[] thirdArray = new int[thirdArrayNum];

        for (int i = 0; i < thirdArrayNum; i++) {
            thirdArray[i] = rand.nextInt(100000) - 50000;
        }

        long thirdStartTime = System.nanoTime();
        find(thirdArray, thirdSum);
        long thirdEndTime = System.nanoTime();
        long thirdTotalTime = thirdEndTime - thirdStartTime;
        System.out.println("Complexity of Time : " + (double) thirdTotalTime / 1000000000 + " Seconds");
        System.out.println();

        /* ********* FORTH TEST ********* */
        System.out.println("input size : 1000000");

        int forthSum = 90;

        int forthArrayNum = 1000000;

        int[] forthArray = new int[forthArrayNum];

        for (int i = 0; i < forthArrayNum; i++) {
            forthArray[i] = rand.nextInt(1000000) - 500000;
        }

        long forthStartTime = System.nanoTime();
        find(forthArray, forthSum);
        long forthEndTime = System.nanoTime();
        long forthTotalTime = forthEndTime - forthStartTime;
        System.out.println("Complexity of Time : " + (double) forthTotalTime / 1000000000 + " Seconds");
        System.out.println();

    }

    public static void find(int[] array, int sum) {
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = i + 1; j < array.length; j++) {
                if (array[i] + array[j] == sum) {
                    System.out.println("Pair found at index " + i + " and " + j);
                    return;
                }
            }
        }

        System.out.println("Pair not found");
    }
}