//Seyed Tavafi
//CS3310
//Midterm
//jump search algorithm( for unsorted array)
import java.util.Arrays;
import java.util.Random;

public class jumpSearch {
    public static void main(String[] args) {
        /* ********* FIRST TEST ********* */
        System.out.println("input size : 100");

        double sum = 80;

        double[] array = new double[100];
        Random rand = new Random();

        for (int i = 0; i < 100; i++) {
            array[i] = rand.nextInt(100) - 50;
        }
//        System.out.println(Arrays.toString(array));

        long startTime = System.nanoTime();
        bubbleSort(array);
//        System.out.println(Arrays.toString(array));
        jumpSearch(array, sum);
        long endTime = System.nanoTime();
        long totalTime = endTime - startTime;
        System.out.println("Complexity of Time : " + (double) totalTime / 1000000000 + " Seconds");
        System.out.println();

        /* ********* SECOND TEST ********* */
        System.out.println("input size : 1000");

        double secondSum = 180;

        double[] secondArray = new double[1000];

        for (int i = 0; i < 1000; i++) {
            secondArray[i] = rand.nextInt(1000) - 500;
        }

        long secondStartTime = System.nanoTime();
        bubbleSort(secondArray);
        jumpSearch(secondArray, secondSum);
        long secondEndTime = System.nanoTime();
        long secondTotalTime = secondEndTime - secondStartTime;
        System.out.println("Complexity of Time : " + (double) secondTotalTime / 1000000000 + " Seconds");
        System.out.println();

        /* ********* THIRD TEST ********* */
        System.out.println("input size : 100000");

        double thirdSum = 180;

        double[] thirdArray = new double[100000];

        for (int i = 0; i < 100000; i++) {
            thirdArray[i] = rand.nextInt(100000) - 50000;
        }

        long thirdStartTime = System.nanoTime();
        bubbleSort(thirdArray);
        jumpSearch(thirdArray, thirdSum);
        long thirdEndTime = System.nanoTime();
        long thirdTotalTime = thirdEndTime - thirdStartTime;
        System.out.println("Complexity of Time : " + (double) thirdTotalTime / 1000000000 + " Seconds");
        System.out.println();

        /* ********* FORTH TEST ********* */
        System.out.println("input size : 1000000");

        double forthSum = 180;
        double[] forthArray = new double[1000000];
        for (int i = 0; i < 1000000; i++) {
            forthArray[i] = rand.nextInt(1000000) - 500000;
        }
        long forthStartTime = System.nanoTime();
        bubbleSort(forthArray);
        jumpSearch(forthArray, forthSum);
        long forthEndTime = System.nanoTime();
        long forthTotalTime = forthEndTime - forthStartTime;
        System.out.println("Complexity of Time : " + (double) forthTotalTime / 1000000000 + " Seconds");
        System.out.println();
    }

    public static void jumpSearch(double[] arr, double sum) {

        for (int i = 0; i < arr.length; i++) {
            double x = sum - arr[i];
            int y = InternalJumpSearch(arr, x);
            if (y != -1) {
                System.out.println("The sum is " + sum);
                System.out.println("indexes :" + i + " and " + y);
                System.out.println("numbers :" + arr[i] + " and " + arr[y]);
                break;
            }
        }
        System.out.println("DONE");

    }

    public static int InternalJumpSearch(double[] arr, double x) {
        int n = arr.length;
        int step = (int) Math.floor(Math.sqrt(n));
        int prev = 0;

        while (arr[Math.min(step, n) - 1] < x) {
            prev = step;
            step += (int) Math.floor(Math.sqrt(n));
            if (prev >= n)
                return -1;
        }

        while (arr[prev] < x) {
            prev++;

            if (prev == Math.min(step, n))
                return -1;
        }

        if (arr[prev] == x)
            return prev;

        return -1;
    }

    public static void bubbleSort(double array[]) {
        int n = array.length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (array[j] > array[j + 1]) {
                    double temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
    }
}
