//Seyed Tavafi
//CS3310
//Midterm
//Linear search algorithm( for sorted array)
import java.util.Arrays;

class Main {
    public static void main(String[] args) {
        /* ********* FIRST TEST ********* */
        System.out.println("input size : 100");
        int sum = 10;
        int[] array = new int[100];
        for (int i = -50; i < 50; i++) {
            array[i + 50] = i;
        }
        System.out.println("sum is :" + sum);
//        System.out.println(Arrays.toString(array));

        long startTime = System.nanoTime();
        find(array, sum);
        long endTime = System.nanoTime();
        long totalTime = endTime - startTime;
        System.out.println("Complexity of Time : " + (double) totalTime / 1000000000 + " Seconds");
        System.out.println();

        /* ********* SECOND TEST ********* */
        System.out.println("input size : 1000");
        int secondSum = 10;
        int[] secondArray = new int[1000];
        for (int i = -500; i < 500; i++) {
            secondArray[i + 500] = i;
        }
        long secondStartTime = System.nanoTime();
        find(secondArray, secondSum);
        long secondEndTime = System.nanoTime();
        long secondTotalTime = secondEndTime - secondStartTime;
        System.out.println("Complexity of Time : " + (double) secondTotalTime / 1000000000 + " Seconds");
        System.out.println();

        /* ********* THIRD TEST ********* */
        System.out.println("input size : 100000");
        int thirdSum = 10;
        int[] thirdArray = new int[100000];
        for (int i = -50000; i < 50000; i++) {
            thirdArray[i + 50000] = i;
        }
        long thirdStartTime = System.nanoTime();
        find(thirdArray, thirdSum);
        long thirdEndTime = System.nanoTime();
        long thirdTotalTime = thirdEndTime - thirdStartTime;
        System.out.println("Complexity of Time : " + (double) thirdTotalTime / 1000000000 + " Seconds");
        System.out.println();

        /* ********* FORTH TEST ********* */
        System.out.println("input size : 1000000");
        int forthSum = 10;
        int[] forthArray = new int[1000000];
        for (int i = -500000; i < 500000; i++) {
            forthArray[i + 500000] = i;
        }
        long forthStartTime = System.nanoTime();
        find(forthArray, forthSum);
        long forthEndTime = System.nanoTime();
        long forthTotalTime = forthEndTime - forthStartTime;
        System.out.println("Complexity of Time : " + (double) forthTotalTime / 1000000000 + " Seconds");
        System.out.println();
    }

    public static void find(int[] array, int sum) {
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = i + 1; j < array.length; j++) {
                if (array[i] + array[j] == sum) {
                    System.out.println("Pair found at index " + i + " and " + j);
                    return;
                }
            }
        }

        System.out.println("Pair not found");
    }
}