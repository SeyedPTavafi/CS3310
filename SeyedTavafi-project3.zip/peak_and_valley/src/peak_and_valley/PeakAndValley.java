//Seyed Tavafi
//CS3310
//project3
package peak_and_valley;

public class PeakAndValley {


        int partitioning(int oldArray[], int start, int end)
        {
                int pivot = oldArray[end];
                int i = (start-1);
                for (int j=start; j<end; j++)
                {
                        if (oldArray[j] < pivot)
                        {
                                i++;
                                int temp = oldArray[i];
                                oldArray[i] = oldArray[j];
                                oldArray[j] = temp;
                        }
                }
                int temp = oldArray[i+1];
                oldArray[i+1] = oldArray[end];
                oldArray[end] = temp;

                return i+1;
        }

        //This is the function where we are implementing the Quicksort
        void sorting(int oldArray[], int start, int end)
        {
                if (start < end)
                {
                        int piv = partitioning(oldArray, start, end);
                        sorting(oldArray, start, piv-1);
                        sorting(oldArray, piv+1, end);
                }
        }

        // we used a function to print the array
        static void displayArray(int newArray[])
        {
                int n = newArray.length;
                for (int i=0; i<n; ++i)
                        System.out.print(newArray[i]+" ");
                System.out.println();
        }
        public static void main(String[] args){
                // we take an array.. An array with odd number of elements
                int oldArray[] = {23, 27, 18, 9, 2, 5 ,33 ,54 ,73 ,65 };
                int n = oldArray.length;
                System.out.print("input:" );
                for(int i=0;i<n;i++)
                {
                	System.out.print(oldArray[i]+" ");
                }
                System.out.println();
                long	startTime1=System.nanoTime();

                // we take new array with same length as old array
                int newArray[] = new int[n];
                PeakAndValley ob = new PeakAndValley();

                //we sort the array using quick sort
                ob.sorting(oldArray, 0, n-1);

                /* we took i = 0 and j= n-1 so that we can refer to the start and end of the array  we took
                        k = n-2 so that if we have odd number of elements we leave the last element as it is
                 and we perform the functioning on n-2 number of element. As it is the largest element since the
                 array is sorted, hence we will end up with a peak at the end and always there will be a valley
                 before that peak. Also we used a variable toggle to toggle between the two idealogies we are using*/
                int i=0;
                int j =n-1;
                int k= n-2;
                int toggle = 0;

                // if old array has even number of elements
                if(n%2==0){
                        while(i<=j){
                                if(toggle==0){
                                        newArray[i]=oldArray[j];
                                        newArray[j]=oldArray[i];
                                        toggle=1;
                                }
                                else if(toggle==1){
                                        newArray[i]=oldArray[i];
                                        newArray[j]=oldArray[j];
                                        toggle=0;
                                }
                                i++;
                                j--;
                        }
                }
                //if old array has odd number of elements
                else if(n%2!=0){
                        while(i<=k){
                                if(toggle==0){
                                        newArray[i]=oldArray[k];
                                        newArray[k]=oldArray[i];
                                        toggle=1;
                                }
                                else if(toggle==1){
                                        newArray[i]=oldArray[i];
                                        newArray[k]=oldArray[k];
                                        toggle=0;
                                }
                                newArray[j]=oldArray[j];
                                i++;
                                k--;
                        }
                }
                long	endTime1=System.nanoTime();
        		long	timeComplexity=endTime1-startTime1;
                System.out.println("inputSize=10 The peak and valley result is: ");
                displayArray(newArray);
                System.out.println("Run Time: "+ timeComplexity + " NanoSeconds");

        }
}

