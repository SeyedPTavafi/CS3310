public class Main {
    public static void main(String[] args) {

        String[] projectsName = {"a", "b", "c", "d", "e", "f"};
        Project[] projects = new Project[projectsName.length];
        for (int i = 0; i < projectsName.length; i++) {
            projects[i] = new Project(projectsName[i]);
        }

        String[][] dependencies = {{"d", "a"}, {"b", "f"}, {"d", "b"}, {"a", "f"}, {"c", "d"}};


        long StartTime = System.nanoTime();
        for (int i = 0; i < projectsName.length; i++) {
            handle(projects, projects[i], dependencies);
        }
        long EndTime = System.nanoTime();
        long TotalTime = EndTime - StartTime;
        System.out.println("Complexity of Time : " +  TotalTime  + " ns");


    }

    public static void handle(Project[] projects, Project project, String[][] dependencies) {
        if (!project.getDone()) {
            for (int i = 0; i < dependencies.length; i++) {
                if (project.getName().equals(dependencies[i][0])) {
                    project.setDependency(true);
                    Project causesProject = findCausesProject(projects, dependencies[i][1]);
                    if (causesProject.getDone() == false) {
                        handle(projects,causesProject , dependencies);
                    }
                    else {
                        project.setDone(true);
                        System.out.println(project.getName());
                    }
                }
            }
            if (!project.getDependency()) {
                project.setDone(true);
                System.out.println(project.getName());
            }
        } else {
            project.setDone(true);
            System.out.println(project.getName());
        }
    }

    public static Project findCausesProject(Project[] projects, String name) {
        Project project = null;
        for (int i = 0; i < projects.length; i++) {
            if (projects[i].getName().equals(name)) {
                project = projects[i];
                break;
            }
        }
        return project;
    }
}