//Seyed Tavafi
//CS3310
//project 3
public class Project {

    private String name;
    private boolean dependency;
    private boolean done;

    public Project(String name) {
        setName(name);
        setDependency(false);
        setDone(false);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDependency(boolean dependency) {
        this.dependency = dependency;
    }

    public void setDone(boolean done) {
        this.done = done;
    }

    public String getName() {
        return name;
    }

    public boolean getDependency() {
        return dependency;
    }

    public boolean getDone() {
        return done;
    }

    public String toString() {
        return "Project{" +
                "name='" + name + '\'' +
                ", done=" + done +
                '}';
    }
}
