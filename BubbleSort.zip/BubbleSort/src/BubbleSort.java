// Seyed tavafi
// Bubble Sort
//Midterm1
//CS3310
import java.util.Random;

class BubbleSort {
    public static void main(String args[]) {

        int arrayNum=500;

        int[] array = new int[arrayNum];

        Random rand = new Random();

        for(int i=0; i<arrayNum; i++)
        {
            array[i]=rand.nextInt(1000);
        }

        BubbleSort bs = new BubbleSort();

        long startTime = System.nanoTime();
        bs.bubbleSort(array);
        long endTime   = System.nanoTime();

        System.out.print("sorted : ");
        bs.printArray(array);
        long totalTime = endTime - startTime;
        System.out.println("Complexity of Time : "+(double)totalTime/1000000000+" Seconds");
    }

    void bubbleSort(int array[]) {
        int n = array.length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
    }

    void printArray(int array[]) {
        int n = array.length;
        for (int i = 0; i < n; ++i)
            System.out.print(array[i] + " ");
        System.out.println();
    }

}